package global;

import org.apache.logging.log4j.Logger;
import org.jessma.mvc.AbstractActionFilter;
import org.jessma.mvc.ActionExecutor;
import org.jessma.util.LogUtil;

public class UserActionFilter extends AbstractActionFilter
{
	Logger logger = LogUtil.getDefaultLogger();
	
	@Override
	public String doFilter(ActionExecutor executor) throws Exception
	{
		logger.debug(">>> User Action Filter (%s#%s())", 
		executor.getAction().getClass().getName(), 
		executor.getEntryMethod().getName());
		String result = executor.invoke();
		logger.debug("User Action Filter <<<");
		
		return result;
	}
}
